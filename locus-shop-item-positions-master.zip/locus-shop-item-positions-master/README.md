
# To run this project, cd into the project folder and run the following
```bash
docker-compose up -d
```